@echo off
cd /d "%~dp0"
python -c "import pymysql, PIL, dotenv, langchain_google_genai" 2>nul
if errorlevel 1 (
  echo Packages are missing. Please double-click setup.bat first.
  pause
  exit /b 1
)
start "" pythonw app.py
