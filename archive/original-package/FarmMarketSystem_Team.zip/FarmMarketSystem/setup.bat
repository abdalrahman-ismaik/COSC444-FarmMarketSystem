@echo off
title Farm-to-Market Setup
cd /d "%~dp0"
echo Installing Python packages...
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo Python was not found or packages failed to install. Install Python 3.10+ from python.org and tick "Add python.exe to PATH".
  pause
  exit /b 1
)
echo.
python setup_database.py
echo.
pause
